//
//  ViewController.swift
//  Odev4
//
//  Created by osmanyesil on 2/26/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }


}

