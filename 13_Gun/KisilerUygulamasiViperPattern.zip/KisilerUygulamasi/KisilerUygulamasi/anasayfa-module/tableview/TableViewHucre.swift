//
//  TableViewHucre.swift
//  KisilerUygulamasi
//
//  Created by Kasım Adalan on 5.03.2022.
//

import UIKit

class TableViewHucre: UITableViewCell {

    @IBOutlet weak var kisiBilgiLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
